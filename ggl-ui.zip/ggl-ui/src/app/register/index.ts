﻿export * from './register.component';
