export class Common {
  username:string;
  password:string;
  country: string;
  address:string;
  qualification:string;
  status:string;
  phoneNumber:string;
  emailID:string;
  industry:string;
  // Investment Module
  paymentStatus:string;
  invoiceNumber:string;
  queueNumber:number;
  userstatus:string;
}
