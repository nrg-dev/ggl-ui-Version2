﻿export * from './details-upload.component';
